<?php

class m131202_225812_content_block extends CDbMigration
{
	// Use safeUp/safeDown to do migration with transaction
	public function safeUp()
	{
		$this->createTable('contentblock', array(
			'Id' => 'pk',
			'Name' => 'varchar(64) NOT NULL',
			'Order' => 'tinyint(2) NOT NULL',
			));
	}

	public function safeDown()
	{
	}
}