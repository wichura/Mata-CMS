<?php

class ContentBlockController extends MataCMSController {

    public function getModel() {
        return ContentBlock::model();
    }
}